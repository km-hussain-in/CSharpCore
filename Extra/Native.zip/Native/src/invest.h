#ifndef INVEST_H
#define INVEST_H

#ifdef __cplusplus
extern "C" {
#endif

double IncomeOnInvestment(double amount, short period, const char* risk);

struct Annuity
{
	double payment;
	int count;
};

double GetFutureValue(const struct Annuity* annuity, float (*rate)(int period));

#ifdef __cplusplus
}
#endif

#endif











