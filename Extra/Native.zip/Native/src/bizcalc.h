#ifndef BIZCALC_H
#define BIZCALC_H

#ifdef __cplusplus
extern "C" {
#endif

float Depreciation(short life, short after, const char* method);

typedef struct{
	int id;
	double amount;
	short period;
}FixedDeposit;


int FixedDepositInit(double amount, short period, FixedDeposit* fd);

double FixedDepositMaturityValue(const FixedDeposit* fd, float(*policy)(short));

#ifdef __cplusplus
}
#endif

#endif











