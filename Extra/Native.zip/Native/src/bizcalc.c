#include "bizcalc.h"
#include "string.h"
#include <time.h>

static float ddb(short life, short after)
{
	float dep = 2.0 / life;
	short y;

	for(y = 1; y < after; ++y)
		dep *= (1 - 2.0 / life);

	return dep;
}

static float syd(short life, short after)
{
	return 2.0 * (life - after) / (life * (life + 1));
}

float Depreciation(short life, short after, const char* method)
{
	if(after >= life)
		return 0.0;

	if(method)
	{
		if(strcmp(method, "ddb") == 0)
			return ddb(life, after);
		if(strcmp(method, "syd") == 0)
			return syd(life, after);
	}

	return 1.0 - (float) after / life;
}


int FixedDepositInit(double amount, short period, FixedDeposit* fd)
{
	static int nxtid;

	if(amount > 1000000 || period > 10)
		return 0;
	
	if(nxtid == 0) nxtid = time(0) % 1000000;
	
	fd->id = nxtid++;
	fd->amount = amount;
	fd->period = period;
	
	return 1;
}

double FixedDepositMaturityValue(const FixedDeposit* fd, float(*policy)(short))
{
	float r = policy ? policy(fd->period) : 6.0f;
	double cash = fd->amount;
	short y;

	for(y = 0; y < fd->period; ++y)	
		cash *= 1 + r / 100;

	return cash;
}

/*
Windows:
	cl /LD bizcalc.c bizcalc.def

Linux:
	cc -shared -fPIC bizcalc.c -o libbizcalc.so
*/
