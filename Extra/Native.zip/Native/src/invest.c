#include "invest.h"
#include "string.h"

double IncomeOnInvestment(double amount, short period, const char* risk)
{
	float rate = 4.0;
	short y;
	double sum = amount;

	if(risk)
	{
		if(strcmp(risk, "low") == 0)
			rate = 6.0;
		else if(strcmp(risk, "medium") == 0)
			rate = 7.5;
		else if(strcmp(risk, "high") == 0)
			rate = 9.5;
	}

	for(y = 0; y < period; ++y)
		sum *= (1 + rate / 100);

	
	return sum - amount;
		
}

double GetFutureValue(const struct Annuity* annuity, float (*rate)(int period))
{
	float i = rate(annuity->count) / 100;
	float j = 1;
	int m;

	for(m = 0; m < annuity->count; ++m)
		j *= (1 + i);		
	
	return annuity->payment * (j - 1) / i;
}


/*
Windows:
	cl /LD invest.c invest.def

Linux:
	cc -shared -fPIC invest.c -o libinvest.so
*/
