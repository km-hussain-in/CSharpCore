#define UNICODE
#include "finance.h"
#include <cmath>
#pragma comment(lib, "ole32")
#pragma comment(lib, "oleaut32")
#pragma comment(lib, "advapi32")

LONG g_cLock;

VOID LockModule(VOID)
{
	InterlockedIncrement(&g_cLock);
}

VOID UnlockModule(VOID)
{
	InterlockedDecrement(&g_cLock);
}

class ReducingBalanceLoan : public ILoan
{
public:
	ReducingBalanceLoan()
	{
		m_cRef = 1;
		m_amount = 0;
		m_period = 0;
		LockModule();
	}

	//IUnknown implementation
	STDMETHODIMP QueryInterface(REFIID riid, LPVOID* ppvObj)
	{
		if(riid == IID_ILoan || riid == IID_IDispatch || riid == IID_IUnknown)
			*ppvObj = static_cast<ILoan*>(this);
		else
			return *ppvObj = NULL, E_NOINTERFACE;

		AddRef();

		return S_OK;
	}

	STDMETHODIMP_(ULONG) AddRef()
	{
		return ++m_cRef;
	}

	STDMETHODIMP_(ULONG) Release()
	{
		if(--m_cRef == 0)
			return delete this, 0;

		return m_cRef;
	}

	//IDispatch implementation
	STDMETHODIMP GetTypeInfoCount(UINT* pctinfo)
	{
		*pctinfo = 1;

		return S_OK;
	}

	STDMETHODIMP GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo** ppTInfo)
	{
		m_pTypeInfo->AddRef();
		*ppTInfo = m_pTypeInfo;

		return S_OK;
	}

	STDMETHODIMP GetIDsOfNames(REFIID riid, LPOLESTR* rgszNames, UINT cNames, LCID lcid, DISPID* rgDispId)
	{
		return m_pTypeInfo->GetIDsOfNames(rgszNames, cNames, rgDispId);		
	}


	STDMETHODIMP Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS* pDispParams, VARIANT* pVarResult, EXCEPINFO* pExcepInfo, UINT* puArgErr)
	{
		return m_pTypeInfo->Invoke(static_cast<ILoan*>(this), dispIdMember, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr);
	}


	//ILoan implementation
	STDMETHODIMP Acquire(double amount, short period)
	{
		if(amount < 10000 * period)
			return LOAN_E_INVALIDAMOUNT;
		if(period < 1 || period > 99)
			return LOAN_E_INVALIDPERIOD;

		m_amount = amount;
		m_period = period;
			
		return S_OK;
	}


	STDMETHODIMP GetInstallmentUsingRate(float rate, double* pResult)
	{
		if(m_period == 0)
			return *pResult = 0, LOAN_E_NOTACQUIRED;

		float i = rate / 1200;
		*pResult = m_amount * i / (1 - std::pow(1 + i, -12 * m_period));

		return S_OK;
	}

	STDMETHODIMP GetInstallmentForScheme(ILoanScheme* pScheme, double* pResult)
	{
		float rate;
		HRESULT hr = pScheme->GetInterestRate(m_period, &rate);

		if(SUCCEEDED(hr))
			hr = GetInstallmentUsingRate(rate, pResult);

		return hr;
	}	
	
	~ReducingBalanceLoan()
	{
		m_pTypeInfo->Release();
		UnlockModule();
	}
private:
	LONG m_cRef;
	double m_amount;
	short m_period;
	ITypeInfo* m_pTypeInfo;

friend class ReducingBalanceLoanClassObject;

};

class ReducingBalanceLoanClassObject : public IClassFactory
{
public:

	//IUnknown implementation

	STDMETHODIMP QueryInterface(REFIID riid, LPVOID* ppvObj)
	{
		if(riid == IID_IClassFactory || riid == IID_IUnknown)
			*ppvObj = static_cast<IClassFactory*>(this);
		else
			return *ppvObj = NULL, E_NOINTERFACE;

		AddRef();

		return S_OK;
	}

	STDMETHODIMP_(ULONG) AddRef()
	{
		LockModule();
		return 2;
	}

	STDMETHODIMP_(ULONG) Release()
	{
		UnlockModule();
		return 1;
	}

	//IClassFactory implementation

	STDMETHODIMP CreateInstance(IUnknown* pUnkOuter, REFIID riid, LPVOID* ppvObj)
	{
		if(pUnkOuter)
			return CLASS_E_NOAGGREGATION;

		ITypeLib* ptlb = NULL;
		HRESULT hr = LoadRegTypeLib(LIBID_FinanceLib, 1, 0, LANG_NEUTRAL, &ptlb);
		if(FAILED(hr)) return hr;

		ReducingBalanceLoan* pObj = new ReducingBalanceLoan;
		ptlb->GetTypeInfoOfGuid(IID_ILoan, &pObj->m_pTypeInfo);
		ptlb->Release();

		hr = pObj->QueryInterface(riid, ppvObj);

		pObj->Release();

		return hr;

	}

	STDMETHODIMP LockServer(BOOL bLock)
	{
		return S_OK; // implemented by local servers only
	}
};

//called by CoGetClassObject
STDAPI DllGetClassObject(REFCLSID clsid, REFIID riid, LPVOID* ppvObj)
{
	if(clsid == CLSID_ReducingBalanceLoan)
	{
		static ReducingBalanceLoanClassObject factory;
		return factory.QueryInterface(riid, ppvObj);
	}
	
	return CLASS_E_CLASSNOTAVAILABLE;
}

//called by CoUninitialize
STDAPI DllCanUnloadNow(VOID)
{
	return g_cLock ? S_FALSE : S_OK;
}

HINSTANCE g_hInstance;

//called by regsvr32
STDAPI DllRegisterServer(VOID)
{
	HKEY hKey1;
	LONG result = RegOpenKeyEx(HKEY_CLASSES_ROOT, L"CLSID", 0, KEY_ALL_ACCESS, &hKey1);
	if(result != ERROR_SUCCESS)
		return E_ACCESSDENIED;

	WCHAR clsid[39];
	StringFromGUID2(CLSID_ReducingBalanceLoan, clsid, 39);
	HKEY hKey2;
	RegCreateKeyEx(hKey1, clsid, 0, NULL, 0, KEY_ALL_ACCESS, NULL, &hKey2, NULL);

	HKEY hKey3;
	RegCreateKeyEx(hKey2, L"InprocServer32", 0, NULL, 0, KEY_ALL_ACCESS, NULL, &hKey3, NULL);

	WCHAR path[MAX_PATH+1];
	DWORD n = GetModuleFileName(g_hInstance, path, MAX_PATH+1);
	RegSetValueEx(hKey3, NULL, 0, REG_SZ, (PBYTE) path, 2 * (n + 1));
	RegSetValueEx(hKey3, L"ThreadingModel", 0, REG_SZ, (PBYTE) L"Apartment", 20);

	RegCloseKey(hKey3); 
	RegCloseKey(hKey2);
	RegCloseKey(hKey1);

	RegCreateKeyEx(HKEY_CLASSES_ROOT, L"FinanceLib.ReducingBalanceLoan", 0, NULL, 0, KEY_ALL_ACCESS, NULL, &hKey1, NULL);
	RegCreateKeyEx(hKey1, L"CLSID", 0, NULL, 0, KEY_ALL_ACCESS, NULL, &hKey2, NULL);
	RegSetValueEx(hKey2, NULL, 0, REG_SZ, reinterpret_cast<LPBYTE>(clsid), 78);
	RegCloseKey(hKey2);
	RegCloseKey(hKey1);

	ITypeLib* ptlb = NULL;
	LoadTypeLibEx(path, REGKIND_REGISTER, &ptlb);
	ptlb->Release();

	return S_OK;
}

//called by regsvr32 /u
STDAPI DllUnregisterServer(VOID)
{
	HKEY hKey1;
	LONG result = RegOpenKeyEx(HKEY_CLASSES_ROOT, L"CLSID", 0, KEY_ALL_ACCESS, &hKey1);
	if(result != ERROR_SUCCESS)
		return E_ACCESSDENIED;

	WCHAR clsid[39];
	StringFromGUID2(CLSID_ReducingBalanceLoan, clsid, 39);
	HKEY hKey2;
	RegOpenKeyEx(hKey1, clsid, 0, KEY_ALL_ACCESS, &hKey2);

	RegDeleteKey(hKey2, L"InprocServer32");
	RegCloseKey(hKey2);

	RegDeleteKey(hKey1, clsid);
	RegCloseKey(hKey1);

	RegOpenKeyEx(HKEY_CLASSES_ROOT, L"FinanceLib.ReducingBalanceLoan", 0, KEY_ALL_ACCESS, &hKey1);
	RegDeleteKey(hKey1, L"CLSID");
	RegCloseKey(hKey1);
	RegDeleteKey(HKEY_CLASSES_ROOT, L"FinanceLib.ReducingBalanceLoan");

	UnRegisterTypeLib(LIBID_FinanceLib, 1, 0, LANG_NEUTRAL, SYS_WIN32);
	
	return S_OK;
}


BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInstance;
		DisableThreadLibraryCalls(hInstance); // do not call DllMain for thread attach/detach
	}

	return TRUE;

}

/*

midl /nologo finance.idl
rc /nologo finance.rc
cl /nologo /LD /EHsc finance.cpp finance_i.c finance.RES finance.def
regsvr32 finance.dll

*/