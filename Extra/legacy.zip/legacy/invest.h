#pragma once

struct FixedDeposit{
	long id;
	double amount;
	int period;
};


int InitFixedDeposit(double amount, int period, struct FixedDeposit* fd);

double GetMaturityValue(const struct FixedDeposit* fd, float(*rate)(int));












