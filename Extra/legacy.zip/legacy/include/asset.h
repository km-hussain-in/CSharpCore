#pragma once

float depreciation(short life, short after, const char* method);




