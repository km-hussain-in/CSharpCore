#pragma once

double depreciated_price(double cost, short life, short after, const char* method);




