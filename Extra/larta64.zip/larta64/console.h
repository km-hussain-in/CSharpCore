#ifndef _CONSOLE_H
#define _CONSOLE_H

void _writestr(char*, long);
void _writeint(long);
void _writeeol(void);
long _readint(void);
void _writedec(double);
double _readdec(void);

#define PutMsg(txt) _writestr(txt, 0)
#define PutInt(val) _writeint(val);_writeeol()
#define GetInt _readint
#define PutDec(val) _writedec(val);_writeeol()
#define GetDec _readdec

#endif

