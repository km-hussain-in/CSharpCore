alter table orders rename constraint SYS_C007033 to FK_ORDERS_CUSTOMERS;
alter table orders rename constraint SYS_C007034 to FK_ORDERS_PRODUCTS;

