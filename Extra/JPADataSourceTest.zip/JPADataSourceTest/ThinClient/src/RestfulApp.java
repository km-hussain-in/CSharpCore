package shopping.api;

@javax.ws.rs.ApplicationPath("/api")
public class RestfulApp extends javax.ws.rs.core.Application{}

