namespace Greeting
{
	public class Greeter
	{
		private bool formal;

		
		public Greeter(bool formal) => this.formal = formal;

		public string Greet(string person)
		{
			return formal ? $"Hello {person}" : $"Hi {person}";
		}
	}
}


