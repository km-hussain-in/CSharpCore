var g = new Greeting.Greeter(true);
System.Console.WriteLine(g.Greet("World!"));

