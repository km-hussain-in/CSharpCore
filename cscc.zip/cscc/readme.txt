INSTALLATION

  Windows
    copy dotnet-csc.cmd %USERPROFILE%\.dotnet\tools

  Linux/macOS
    cp dotnet-csc $HOME/.dotnet/tools
    chmod +x $HOME/.dotnet/tools/dotnet-csc
    export PATH=$PATH:$HOME/.dotnet/tools


USAGE

  dotnet csc greeter.cs -t:library
  dotnet csc hello.cs -r:greeter.dll
  dotnet hello.exe




  

